import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Stack;

class Interval {
	int start, end;

	Interval(int start, int end) {
		this.start = start;
		this.end = end;
	}
}

public class Lab7_43 {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of intervals: ");
		int n = sc.nextInt();
		Interval intervals[] = new Interval[n];
		for(int i=0; i<n; i++) {
			System.out.println("Enter the start of interval " + (i+1) + ": ");
			int start = sc.nextInt();
			System.out.println("Enter the end of interval " + (i+1) + ": ");
			int end = sc.nextInt();
			intervals[i] = new Interval(start, end);
		}
		mergeIntervals(intervals);
		sc.close();
	}


	public static void mergeIntervals(Interval intervals[]) {
		if (intervals.length <= 0)
			return;

			Stack<Interval> stack = new Stack<>();


		Arrays.sort(intervals, new Comparator<Interval>() {
			public int compare(Interval i1, Interval i2) {
				return i1.start - i2.start;
			}
		});

		stack.push(intervals[0]);

		for (int i = 1; i < intervals.length; i++) {
			Interval top = stack.peek();

		
			if (top.end < intervals[i].start)
				stack.push(intervals[i]);

			// Otherwise update the ending time of top if
			// ending of current interval is more
			else if (top.end < intervals[i].end) {
				top.end = intervals[i].end;
				stack.pop();
				stack.push(top);
			}
		}

		// Print contents of stack
		System.out.print("The Merged Intervals are: ");
		while (!stack.isEmpty()) {
			Interval t = stack.pop();
			System.out.print("[" + t.start + "," + t.end+ "] ");
		}
	}
}